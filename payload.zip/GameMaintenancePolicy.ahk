#Requires AutoHotkey v2.0

; Pure scheduling policy. No time, process, file, HTTP, global state or input calls.
GM_Value(value, key, fallback := "") {
    if !IsObject(value)
        return fallback
    if value is Map
        return value.Has(key) ? value[key] : fallback
    return value.HasOwnProp(key) ? value.%key% : fallback
}

GM_DefaultState() {
    return {schemaVersion:1, phase:"CHECKING_NOTICE", overlay:"", eventId:"", revision:"", gameVersion:"", sourceUrl:"",
        startsAt:0, expectedOpenAt:0, provider:"unknown", fingerprint:"", runCycle:"", targetServer:"",
        actionId:"", actionStage:"", f11InputAttempted:0, cancelled:0, desiredState:"RUN", remoteGeneration:0,
        elapsedMs:0, lastObserveElapsedMs:0, lastActivityElapsedMs:-1, lastNoticeCheckElapsedMs:-300000, helperRestarts:0, updatedAtUtcMs:0,
        updaterUiActionId:"",updaterUiActionStage:"",notificationKeys:"",notifiedOpenAt:0,recoveryUncertain:0,f11OkwwIdentity:""}
}

GM_WaitForUpdateExit(hooks, timeoutMs := 30000) {
    started := hooks.Now.Call()
    loop {
        alive := hooks.Alive.Call()
        if alive == "unknown"
            return "unverified"
        if !alive
            return "exited"
        if hooks.Now.Call() - started >= timeoutMs
            return "timeout"
        hooks.Wait.Call(Min(250, timeoutMs - (hooks.Now.Call() - started)))
    }
}

GM_LoginActionAllowed(decision, updateUi := false) {
    if !IsObject(decision) || decision.overlay != ""
        return false
    ; Update-dialog inspection is not permission to log in or send F11.
    ; The host additionally requires the verified selected game HWND.
    if updateUi && decision.effect.type = "observe"
        && InStr(",CHECKING_UPDATE,UPDATING,","," decision.phase ",",true)
        return true
    return decision.effect.type = "resume_flow"
        && InStr(",NORMAL,CHECKING_LOGIN,READY,","," decision.phase ",",true)
}

GM_SelectGameIdentity(candidates,expectedPath,pinned := 0) {
    if expectedPath = ""
        return 0
    selected := 0
    for candidate in candidates {
        if !GM_Value(candidate,"valid",false) || GM_Value(candidate,"started",0) <= 0
            || StrLower(GM_Value(candidate,"path","")) != StrLower(expectedPath)
            continue
        if IsObject(selected)
            return 0
        selected := candidate
    }
    if !IsObject(selected)
        return 0
    if IsObject(pinned) && (selected.pid != pinned.pid || selected.started != pinned.started || selected.hwnd != pinned.hwnd
        || StrLower(selected.path) != StrLower(pinned.path))
        return 0
    return selected
}

GM_CanResumeF11(state,observation,okwwIdentity,nowMs) {
    return state.f11InputAttempted && state.f11OkwwIdentity != "" && okwwIdentity = state.f11OkwwIdentity
        && GM_Value(observation,"phase","") = "game_ready" && GM_Value(observation,"identityVerified",false)
        && GM_Value(observation,"stable",false) && GM_Value(observation,"observedAt",0) >= nowMs - 60000
        && GM_Value(observation,"observedAt",0) <= nowMs + 5000
}

GM_CopyState(original) {
    result := GM_DefaultState()
    for key, value in result.OwnProps() {
        if IsObject(original) && original.HasOwnProp(key)
            result.%key% := original.%key%
    }
    return result
}

GM_Decision(state, phase, effect := "none", errorCode := "", detail := "", overlay := "") {
    state.phase := phase, state.overlay := overlay
    return {phase:phase, overlay:overlay, errorCode:errorCode, detail:detail, state:state,
        effect:{type:effect, actionId:effect = "start_update" ? state.eventId ":" state.fingerprint ":update" : "",
            expectedRevision:state.revision, expectedRemoteGeneration:state.remoteGeneration}}
}

GM_Evaluate(previous, input) {
    if GM_Value(input,"maintenancePolicy","") = "skip_update_day"
        return GM_EvaluateDaySkip(previous,input)
    state := GM_CopyState(previous), now := GM_Value(input,"nowUtcMs",0), elapsed := GM_Value(input,"elapsedMs",0)
    state.desiredState := GM_Value(input,"desiredState","PAUSE"), state.remoteGeneration := GM_Value(input,"remoteGeneration",0)
    state.elapsedMs := elapsed, state.updatedAtUtcMs := now
    if (state.desiredState = "STOP") {
        state.cancelled := true, state.actionStage := "cancelled", state.recoveryUncertain := false
        return GM_Decision(state,"STOPPED","stop","","已取消本腳本後續更新及登入動作")
    }
    if state.cancelled {
        if !GM_Value(input,"newTask",false)
            return GM_Decision(state,"STOPPED","none","","前一任務已取消，等待明確新任務")
        state.cancelled := false, state.actionId := "", state.actionStage := "", state.f11InputAttempted := false
    }
    if state.recoveryUncertain
        return GM_Decision(state,"NEEDS_ATTENTION","none","JOURNAL_RECOVERY_UNCERTAIN","已恢復備份，但無法證明最新動作／停止意圖；請先停止，再明確啟動新任務")
    notice := GM_Value(input,"notice",0), sourceState := GM_Value(input,"noticeState","pending")
    if IsObject(notice) && GM_Value(notice,"eventId","") != "" {
        if (state.eventId != "" && state.eventId != notice.eventId)
            return GM_Decision(state,"WAIT_NOTICE","none","NOTICE_CONFLICT","公告事件與接續任務不一致")
        state.eventId := notice.eventId
        ; A stale source may not shorten an already persisted deadline.
        if GM_Value(notice,"expectedOpenAt",0) >= state.expectedOpenAt {
            state.expectedOpenAt := GM_Value(notice,"expectedOpenAt",0), state.revision := GM_Value(notice,"revision","")
        }
        state.startsAt := GM_Value(notice,"startsAt",state.startsAt)
        state.gameVersion := GM_Value(notice,"gameVersion",state.gameVersion)
        state.sourceUrl := GM_Value(notice,"sourceUrl",state.sourceUrl)
    }
    if (state.desiredState != "RUN")
        return GM_Decision(state,state.phase,"none","","遠端暫停；不操作更新器","PAUSE")
    if !GM_Value(input,"desktopAvailable",false)
        return GM_Decision(state,state.phase,"none","","桌面鎖定；等待解鎖","WAIT_DESKTOP")
    if !GM_Value(input,"clockStable",false) {
        effect := elapsed - state.lastNoticeCheckElapsedMs >= 300000 ? "check_notice" : "none"
        if effect = "check_notice"
            state.lastNoticeCheckElapsedMs := elapsed
        return GM_Decision(state,"WAIT_NOTICE",effect,"CLOCK_CHANGED","系統時間變更，重新確認公告")
    }
    if GM_Value(input,"runCycle",state.runCycle) != state.runCycle
        return GM_Decision(state,state.phase,"reconcile_schedule","","循環日已變更，先核對伺服器排程")
    observation := GM_Value(input,"observation",0), observedPhase := GM_Value(observation,"phase","unknown")
    observationFresh := (now - GM_Value(observation,"observedAt",0) <= 60000 && GM_Value(observation,"observedAt",0) <= now + 5000)
    if !observationFresh
        observedPhase := "unknown"
    if (observedPhase = "maintenance" && GM_Value(observation,"confirmed",false) && GM_Value(observation,"identityVerified",false)) {
        if state.phase != "WAIT_SERVER"
            state.lastObserveElapsedMs := elapsed
        return GM_Decision(state,"WAIT_SERVER","none","","遊戲明確顯示維護，每五分鐘重新確認")
    }
    if (state.phase = "WAIT_SERVER") {
        serverDeadline := state.expectedOpenAt
        if (GM_Value(input,"delayEventId","") = state.eventId && GM_Value(input,"delayUntilUtc",0) > now && GM_Value(input,"delayUntilUtc",0) - now <= 172800000)
            serverDeadline := Max(serverDeadline,GM_Value(input,"delayUntilUtc",0))
        if (state.eventId != "") {
            if (GM_Value(input,"skipEventId","") != state.eventId && now < serverDeadline)
                return GM_Decision(state,"WAIT_SERVER","none","","維護畫面已恢復，仍須等公告開服時間")
            if (sourceState != "valid" || !IsObject(notice) || !GM_Value(notice,"freshForRelease",false) || GM_Value(notice,"revision","") != state.revision
                || (GM_Value(input,"skipEventId","") != state.eventId && GM_Value(notice,"checkedAt",0) < state.expectedOpenAt)) {
                effect := elapsed - state.lastNoticeCheckElapsedMs >= 300000 ? "check_notice" : "none"
                if effect = "check_notice"
                    state.lastNoticeCheckElapsedMs := elapsed
                return GM_Decision(state,"WAIT_SERVER",effect,"NOTICE_RECHECK_REQUIRED","仍需最新官方公告確認")
            }
        }
        if (observedPhase = "game_ready" && GM_Value(observation,"identityVerified",false) && GM_Value(observation,"stable",false))
            return GM_Decision(state,"READY","resume_flow","","主畫面已穩定驗證，接續流程")
        if (observedPhase = "login_ready" && state.f11InputAttempted)
            return GM_Decision(state,"NEEDS_ATTENTION","none","LOGIN_RESUME_UNCONFIRMED","已送過 F11；未確認可安全接續，不重送切換快捷鍵")
        if (observedPhase = "login_ready" && !state.f11InputAttempted)
            return GM_Decision(state,"CHECKING_LOGIN","resume_flow","","維護提示已消失，接回既有登入流程")
        if (elapsed - state.lastObserveElapsedMs >= 300000) {
            state.lastObserveElapsedMs := elapsed
            return GM_Decision(state,"WAIT_SERVER","observe")
        }
        return GM_Decision(state,"WAIT_SERVER")
    }
    if (GM_Value(input,"noticeErrorCode","") = "NOTICE_CONFLICT")
        return GM_Decision(state,"WAIT_NOTICE","none","NOTICE_CONFLICT","多份公告時間衝突，等待重新確認")
    if (state.eventId = "") {
        if GM_Value(input,"requireLauncher",false) && (sourceState = "valid" || !GM_Value(input,"enabled",true)
            || (sourceState != "pending" && elapsed >= 20000))
            return GM_EvaluateLauncher(state,input,observedPhase)
        if (sourceState = "valid" || !GM_Value(input,"enabled",true))
            return GM_Decision(state,"NORMAL","resume_flow")
        if (sourceState != "pending" && elapsed >= 20000)
            return GM_Decision(state,"NORMAL","resume_flow","NOTICE_UNAVAILABLE","公告確認失敗；沿用平日流程並保留遊戲內維護備援")
        return GM_Decision(state,"CHECKING_NOTICE")
    }
    deadline := state.expectedOpenAt
    if (GM_Value(input,"delayEventId","") = state.eventId && GM_Value(input,"delayUntilUtc",0) > now && GM_Value(input,"delayUntilUtc",0) - now <= 172800000)
        deadline := Max(deadline,GM_Value(input,"delayUntilUtc",0))
    skip := GM_Value(input,"skipEventId","") = state.eventId
    if (!skip && now < deadline)
        return GM_Decision(state,"WAIT_OPEN","none","","等待官方公告開服時間；不提前更新")
    ; An event-scoped skip changes the clock gate only, never source validation.
    if (sourceState != "valid" || !IsObject(notice) || !GM_Value(notice,"freshForRelease",false) || GM_Value(notice,"revision","") != state.revision
        || (!skip && GM_Value(notice,"checkedAt",0) < state.expectedOpenAt)) {
        effect := elapsed - state.lastNoticeCheckElapsedMs >= 300000 ? "check_notice" : "none"
        if effect = "check_notice"
            state.lastNoticeCheckElapsedMs := elapsed
        return GM_Decision(state,"WAIT_NOTICE",effect,"NOTICE_RECHECK_REQUIRED","到達時間，仍需最新官方公告確認")
    }
    return GM_EvaluateLauncher(state,input,observedPhase)
}

; Calendar days are Asia/Taipei (UTC+8), not the farming 04:00 cycle.
; This policy deliberately has NO updater/launcher effect. Legacy policy above
; remains readable for old journals/tests but the production host selects this.
GM_EvaluateDaySkip(previous,input) {
    state := GM_CopyState(previous), now := GM_Value(input,"nowUtcMs",0)
    state.desiredState := GM_Value(input,"desiredState","PAUSE")
    state.remoteGeneration := GM_Value(input,"remoteGeneration",state.remoteGeneration)
    state.updatedAtUtcMs := now
    if state.desiredState = "STOP" || state.cancelled
        return GM_Decision(state,"STOPPED","stop","","停止要求優先；不啟動或更新遊戲")
    if state.desiredState != "RUN"
        return GM_Decision(state,state.phase,"none","","遠端暫停","PAUSE")
    if state.recoveryUncertain
        return GM_Decision(state,"NEEDS_ATTENTION","none","JOURNAL_RECOVERY_UNCERTAIN","無法確認停止意圖；保留狀態，不啟動遊戲")
    if !GM_Value(input,"clockStable",false) || now <= 0
        return GM_Decision(state,"WAIT_NOTICE","none","CLOCK_CHANGED","時間尚未確認；不啟動遊戲")
    today := Floor((now+28800000)/86400000)
    if GM_Value(input,"enabled",true) {
        ; The preview is important: at 00:00 the 04:00 notice is not active yet.
        for event in [GM_Value(input,"notice",0),GM_Value(input,"upcomingNotice",0),state] {
            starts := GM_Value(event,"startsAt",0), finish := GM_Value(event,"expectedOpenAt",0)
            if GM_Value(event,"eventId","") = "" || starts <= 0 || finish <= starts
                continue
            firstDay := Floor((starts+28800000)/86400000)
            lastDay := Floor((finish+28800000-1)/86400000)
            if today < firstDay || today > lastDay
                continue
            state.eventId := event.eventId, state.startsAt := starts, state.expectedOpenAt := finish
            state.revision := GM_Value(event,"revision",state.revision)
            state.gameVersion := GM_Value(event,"gameVersion",state.gameVersion)
            state.sourceUrl := GM_Value(event,"sourceUrl",state.sourceUrl)
            return GM_Decision(state,"SKIPPED_UPDATE_DAY","none","",
                "官方版本更新日（台灣時間）整天不執行鋤地、不啟動或更新遊戲；保留任務與完成清單，次日排程再檢查。")
        }
        source := GM_Value(input,"noticeState","pending")
        if GM_Value(input,"noticeErrorCode","") = "NOTICE_CONFLICT"
            return GM_Decision(state,"WAIT_NOTICE","none","NOTICE_CONFLICT","公告日期衝突；不啟動遊戲")
        if source = "pending" || (source != "valid" && GM_Value(input,"elapsedMs",0) < 20000)
            return GM_Decision(state,"CHECKING_NOTICE")
    }
    if !GM_Value(input,"desktopAvailable",false)
        return GM_Decision(state,state.phase,"none","","桌面鎖定；等待解鎖","WAIT_DESKTOP")
    if GM_Value(input,"runCycle",state.runCycle) != state.runCycle
        return GM_Decision(state,state.phase,"reconcile_schedule")
    if !GM_Value(GM_Value(input,"install",0),"identityVerified",false) {
        if GM_Value(input,"elapsedMs",0) >= 60000
            return GM_Decision(state,"NEEDS_ATTENTION","none","INSTALL_IDENTITY_UNVERIFIED","一分鐘內無法確認安裝身分；不清場、不啟動遊戲")
        return GM_Decision(state,"CHECKING_INSTALL","none","","確認原設定的安裝目錄；尚不清場或啟動遊戲")
    }
    ; Old update intents cannot force the retired updater on an ordinary day.
    state.actionId := "", state.actionStage := "", state.f11InputAttempted := false
    state.provider := GM_Value(GM_Value(input,"install",0),"provider","unknown")
    state.fingerprint := GM_Value(GM_Value(input,"install",0),"fingerprint",state.fingerprint)
    return GM_Decision(state,"NORMAL","resume_flow","","非版本更新日，使用原設定安裝的遊戲入口與既有登入流程；不自動操作更新器。")
}

GM_EvaluateLauncher(state,input,observedPhase) {
    observation := GM_Value(input,"observation",0)
    if (observedPhase = "game_running" || observedPhase = "login_ready") && !GM_Value(observation,"identityVerified",false)
        observedPhase := "unknown"
    install := GM_Value(input,"install",0)
    state.provider := GM_Value(install,"provider","unknown"), state.fingerprint := GM_Value(install,"fingerprint",state.fingerprint)
    launchAdapterReady := GM_Value(install,"launchAdapterReady",GM_Value(install,"updateAdapterReady",false))
    if (state.provider != "steam" && state.provider != "kuro")
        return GM_Decision(state,"NEEDS_ATTENTION","none","INSTALL_SOURCE_UNKNOWN","無法確認安裝來源，請檢查鳴潮啟動路徑")
    if (observedPhase = "game_ready" && GM_Value(observation,"identityVerified",false) && GM_Value(observation,"stable",false))
        return GM_Decision(state,"READY","resume_flow")
    if (observedPhase = "error" || observedPhase = "login_required" || observedPhase = "offline" || observedPhase = "paused_download")
        return GM_Decision(state,"NEEDS_ATTENTION","none",GM_Value(observation,"errorCode","UPDATER_" StrUpper(observedPhase)),GM_Value(observation,"detail","更新器需要人工確認"))
    if (observedPhase = "update_ready") {
        if state.actionId = "" && launchAdapterReady
            return GM_Decision(state,"CHECKING_UPDATE","start_update")
        return GM_Decision(state,"CHECKING_UPDATE","observe","","更新器已就緒，仍在等待目標遊戲程序")
    }
    if (observedPhase = "game_running" || observedPhase = "login_ready")
        return GM_Decision(state,"CHECKING_LOGIN","resume_flow","","更新器或程序已就緒；尚未宣告遊戲登入成功")
    if InStr(",downloading,installing,verifying,queued,","," observedPhase ",",true) {
        if GM_Value(input,"noProgressMs",0) >= 1800000
            return GM_Decision(state,"NEEDS_ATTENTION","none","UPDATE_STALLED","三十分鐘沒有可證實的更新進展")
        state.lastActivityElapsedMs := GM_Value(input,"elapsedMs",0)
        return GM_Decision(state,"UPDATING","observe")
    }
    if (state.actionId != "" && (state.actionStage = "intent" || state.actionStage = "observed")) {
        idleMs := state.lastActivityElapsedMs < 0 ? GM_Value(input,"actionElapsedMs",0)
            : Min(GM_Value(input,"actionElapsedMs",0),Max(0,GM_Value(input,"elapsedMs",0)-state.lastActivityElapsedMs))
        if idleMs >= 180000
            return GM_Decision(state,"NEEDS_ATTENTION","none","UPDATE_ACTIVITY_UNCONFIRMED","已發起更新但三分鐘內無法確認活動；不重複啟動")
        return GM_Decision(state,"CHECKING_UPDATE","observe","","接續上次動作，先核對更新器與遊戲")
    }
    if !launchAdapterReady
        return GM_Decision(state,"NEEDS_ATTENTION","none","UPDATE_ADAPTER_UNVERIFIED","已辨識安裝來源，但更新操作尚未完成實機驗證")
    return GM_Decision(state,"CHECKING_UPDATE","start_update")
}
